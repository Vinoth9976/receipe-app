// import "./Footer.css"

export default function footer(){
    return     <footer className="footer py-1 bg-dark">
    <p className="text-center text-white mt-1 ">
      RECIPE - All Rights Reserved
    </p>
  </footer>
}